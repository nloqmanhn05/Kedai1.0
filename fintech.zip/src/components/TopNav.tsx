import { Bell, HelpCircle, LogOut, Search } from 'lucide-react';

export function TopNav() {
  return (
    <header className="flex items-center justify-between px-8 py-6 flex-shrink-0 z-10 w-full">
      <div className="relative w-64 max-w-sm hidden sm:block">
        <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
        <input 
          type="text" 
          placeholder="Search operations..." 
          className="w-full pl-10 pr-4 py-2 bg-transparent border-none text-sm focus:ring-0 text-gray-600 placeholder-gray-400 outline-none" 
        />
      </div>
      <div className="flex items-center gap-4 ml-auto text-gray-600">
        <button className="p-2 hover:bg-gray-100 rounded-full relative transition-colors">
          <Bell className="w-5 h-5" />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full border-2 border-brand-bg"></span>
        </button>
        <button className="p-2 hover:bg-gray-100 rounded-full transition-colors">
          <HelpCircle className="w-5 h-5" />
        </button>
        <button className="p-2 hover:bg-gray-100 rounded-full transition-colors">
          <LogOut className="w-5 h-5" />
        </button>
      </div>
    </header>
  );
}
