import { LayoutDashboard, BookOpen, Bot, Settings } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import { cn } from '../lib/utils';

export function Sidebar() {
  const location = useLocation();

  const navItems = [
    { name: 'Dashboard', path: '/dashboard', icon: LayoutDashboard },
    { name: 'Ledger', path: '/ledger', icon: BookOpen },
    { name: 'AI Assistant', path: '/assistant', icon: Bot },
    { name: 'Settings', path: '/settings', icon: Settings },
  ];

  return (
    <aside className="w-64 bg-brand-sidebar flex-shrink-0 flex-col border-r border-gray-100 hidden md:flex h-full">
      <div className="p-8">
        <div className="flex flex-col">
          <span className="text-xl font-bold text-blue-900 tracking-tight">FinTech</span>
          <span className="text-xs text-gray-500 font-medium mt-0.5">HawkerTrack</span>
        </div>
      </div>
      <nav className="flex-1 px-4 space-y-2 mt-4">
        {navItems.map((item) => {
          const isActive = location.pathname === item.path;
          return (
            <Link
              key={item.name}
              to={item.path}
              className={cn(
                "flex items-center gap-4 px-4 py-3 rounded-2xl transition-colors",
                isActive
                  ? "bg-brand-purple text-white"
                  : "text-gray-500 hover:text-gray-900"
              )}
            >
              <item.icon className={cn("w-5 h-5", isActive && "opacity-90")} />
              <span className="font-medium text-sm">{item.name}</span>
            </Link>
          );
        })}
      </nav>
    </aside>
  );
}
