import React from 'react';
import { Sidebar } from '../components/Sidebar';
import { TopNav } from '../components/TopNav';
import { TrendingUp, Wallet, ArrowRight, FileText, Cloud, ArrowLeftRight } from 'lucide-react';
import { AreaChart, Area, XAxis, Tooltip as RechartsTooltip, ResponsiveContainer } from 'recharts';

const chartData = [
  { name: '24/3', Value: 15, transaction: 10 },
  { name: '25/3', Value: 30, transaction: 15 },
  { name: '26/3', Value: 20, transaction: 8 },
  { name: '27/3', Value: 35, transaction: 20 },
  { name: '28/3', Value: 65, transaction: 30 },
  { name: '29/3', Value: 75, transaction: 45 },
  { name: '30/3', Value: 70, transaction: 25 },
];

export default function Dashboard() {
  return (
    <div className="flex h-screen overflow-hidden antialiased bg-brand-bg text-on-surface">
      <Sidebar />
      <main className="flex-1 flex flex-col h-full overflow-hidden relative">
        <TopNav />
        <div className="flex-1 overflow-y-auto px-4 sm:px-8 pb-12">
          <div className="max-w-md mx-auto xl:max-w-full xl:grid xl:grid-cols-12 xl:gap-8">
            
            {/* Header Info */}
            <div className="mb-8 xl:col-span-12 flex justify-between items-start">
              <div className="max-w-xs">
                <h1 className="text-3xl font-bold text-gray-900 leading-tight mb-2">
                  Financial<br />Overview
                </h1>
                <p className="text-sm text-gray-500 leading-relaxed">
                  A clear view of your operational liquidity and recent performance metrics.
                </p>
              </div>
              <div className="text-right flex flex-col items-end">
                <span className="text-xs text-gray-400 font-medium uppercase tracking-wider">Last synced</span>
                <span className="text-sm font-semibold text-gray-900 mt-1">Today,<br />09:41 AM</span>
              </div>
            </div>

            {/* Left Column */}
            <div className="space-y-6 xl:col-span-5">
              
              {/* Total Cash Card */}
              <div className="bg-white rounded-[32px] p-8 shadow-[0_4px_20px_rgba(0,0,0,0.03)] relative overflow-hidden">
                <div className="flex justify-between items-start mb-2">
                  <span className="text-xs font-bold text-gray-500 tracking-wider uppercase">Total Cash In Hand</span>
                </div>
                <div className="flex items-center justify-between mb-8">
                  <h2 className="text-5xl font-bold text-gray-900 tracking-tight">
                    <span className="text-3xl mr-1">RM</span>42,500
                  </h2>
                  <div className="bg-blue-100 text-blue-600 px-3 py-1 rounded-full text-sm font-semibold flex items-center gap-1">
                    <TrendingUp className="w-3 h-3" />
                    12.4%
                  </div>
                </div>
                <div className="pt-6 border-t border-gray-100">
                  <h3 className="text-xs font-bold text-gray-400 tracking-wider uppercase mb-4">Today's Activity</h3>
                  <div className="flex justify-between">
                    <div>
                      <p className="text-xs text-gray-500 mb-1">Earned Today</p>
                      <p className="text-lg font-bold text-blue-700">+ RM 12,450</p>
                    </div>
                    <div className="text-right">
                      <p className="text-xs text-gray-500 mb-1">Spent Today</p>
                      <p className="text-lg font-bold text-gray-900">- RM2,140</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Cash vs E-wallet */}
              <div className="bg-[#fcfcff] rounded-[32px] p-8 shadow-[0_4px_20px_rgba(0,0,0,0.03)] flex flex-col items-center">
                <h3 className="text-base font-bold text-gray-900 mb-6 w-full text-left">Cash vs E-wallet</h3>
                <div className="relative w-48 h-48 mb-6">
                  <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                    <circle cx="50" cy="50" fill="transparent" r="40" stroke="#f3f4f6" strokeWidth="8"></circle>
                    <circle cx="50" cy="50" fill="transparent" r="30" stroke="#f3f4f6" strokeWidth="8"></circle>
                    <circle cx="50" cy="50" fill="transparent" r="40" stroke="#1A56DB" strokeDasharray="188.5" strokeDashoffset="62.8" strokeLinecap="round" strokeWidth="8"></circle>
                    <circle cx="50" cy="50" fill="transparent" r="30" stroke="#7C3AED" strokeDasharray="188.5" strokeDashoffset="113.1" strokeLinecap="round" strokeWidth="8"></circle>
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <div className="bg-white rounded-full p-2.5 shadow-sm flex items-center justify-center">
                      <Wallet className="text-blue-800 w-6 h-6" />
                    </div>
                  </div>
                </div>
                <div className="flex gap-8 w-full justify-center">
                  <div className="text-center">
                    <p className="text-sm font-bold text-gray-900">RM 31,875</p>
                    <div className="flex items-center justify-center gap-1.5 mt-1">
                      <span className="w-2 h-2 rounded-full bg-blue-800"></span>
                      <span className="text-xs text-gray-500">Cash</span>
                    </div>
                  </div>
                  <div className="text-center">
                    <p className="text-sm font-bold text-gray-900">RM 10,625</p>
                    <div className="flex items-center justify-center gap-1.5 mt-1">
                      <span className="w-2 h-2 rounded-full bg-purple-600"></span>
                      <span className="text-xs text-gray-500">E-wallet</span>
                    </div>
                  </div>
                </div>
              </div>

            </div>

            {/* Right Column */}
            <div className="space-y-6 mt-6 xl:mt-0 xl:col-span-7">
              
              {/* Monthly Chart */}
              <div className="bg-white rounded-[32px] p-8 shadow-[0_4px_20px_rgba(0,0,0,0.03)] flex flex-col md:flex-row gap-8">
                <div className="w-full md:w-[30%] flex flex-col">
                  <h3 className="text-base font-bold text-gray-900">March 2026</h3>
                  <div className="mt-8 mb-8">
                    <span className="text-xs font-bold text-gray-400 tracking-wider uppercase block mb-2">Total Transactions</span>
                    <span className="text-4xl font-bold text-[#1A56DB]">142</span>
                  </div>
                  <div className="mt-auto flex items-center gap-2">
                    <span className="w-3 h-3 rounded-sm bg-[#14b8a6]"></span>
                    <span className="text-xs text-gray-500">transaction</span>
                  </div>
                </div>
                <div className="w-full md:w-[70%] flex flex-col">
                  <div className="flex justify-end mb-4">
                    <a href="#" className="text-sm font-medium text-[#1A56DB] hover:text-blue-800">View Full Report</a>
                  </div>
                  <div className="h-48 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={chartData} margin={{ top: 10, right: 0, left: 0, bottom: 0 }}>
                        <defs>
                          <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#1A56DB" stopOpacity={0.2}/>
                            <stop offset="95%" stopColor="#1A56DB" stopOpacity={0}/>
                          </linearGradient>
                          <linearGradient id="colorTransaction" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#14b8a6" stopOpacity={0.3}/>
                            <stop offset="95%" stopColor="#14b8a6" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <XAxis 
                          dataKey="name" 
                          axisLine={false} 
                          tickLine={false} 
                          tick={{ fill: '#9ca3af', fontSize: 10 }}
                          dy={10}
                        />
                        <RechartsTooltip 
                          contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)' }}
                        />
                        <Area type="monotone" dataKey="transaction" stroke="#14b8a6" strokeWidth={2} fillOpacity={1} fill="url(#colorTransaction)" />
                        <Area type="monotone" dataKey="Value" stroke="#1A56DB" strokeWidth={3} fillOpacity={1} fill="url(#colorValue)" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>

              {/* Sales Summary */}
              <div className="bg-[#fcfcff] rounded-[32px] p-8 shadow-[0_4px_20px_rgba(0,0,0,0.03)]">
                <h3 className="text-base font-bold text-gray-900 mb-6">Sales Summary</h3>
                <div className="space-y-4">
                  <div className="flex justify-between items-center py-2 border-b border-gray-100 last:border-0">
                    <span className="text-sm text-gray-500">Starting Cash</span>
                    <span className="text-sm font-bold text-gray-900">RM 5,420.00</span>
                  </div>
                  <div className="flex justify-between items-center py-2 border-b border-gray-100 last:border-0">
                    <span className="text-sm text-gray-500">Expected Cash</span>
                    <span className="text-sm font-bold text-gray-900">RM 8,200.00</span>
                  </div>
                  <div className="flex justify-between items-center py-2 border-b border-gray-100 last:border-0">
                    <span className="text-sm text-gray-500">Gross Sales</span>
                    <span className="text-sm font-bold text-blue-700">RM 12,450.00</span>
                  </div>
                  <div className="flex justify-between items-center py-2 border-b border-gray-100 last:border-0">
                    <span className="text-sm text-gray-500">Refund</span>
                    <span className="text-sm font-bold text-red-600">RM 150.00</span>
                  </div>
                  <div className="flex justify-between items-center pt-2">
                    <span className="text-sm text-gray-500">Discount</span>
                    <span className="text-sm font-bold text-gray-900">RM 200.00</span>
                  </div>
                </div>
              </div>

              {/* Recent Activity */}
              <div className="bg-white rounded-[32px] p-8 shadow-[0_4px_20px_rgba(0,0,0,0.03)]">
                <div className="flex justify-end mb-4">
                  <a href="#" className="text-sm font-medium text-blue-600 hover:text-blue-800 flex items-center gap-1">
                    View Ledger <ArrowRight className="w-4 h-4" />
                  </a>
                </div>
                <div className="space-y-6">
                  {/* Item 1 */}
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center flex-shrink-0">
                      <FileText className="w-5 h-5 text-gray-600" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-bold text-gray-900 truncate">Invoice Paid #INV-2023-081</p>
                      <p className="text-xs text-gray-500 truncate mt-0.5">Client: Nexus Innovations</p>
                    </div>
                    <div className="text-right flex-shrink-0">
                      <p className="text-sm font-bold text-blue-700">+ RM 12,450.00</p>
                      <p className="text-xs text-gray-400 mt-0.5">Today, 10:24 AM</p>
                    </div>
                  </div>
                  {/* Item 2 */}
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center flex-shrink-0">
                      <Cloud className="w-5 h-5 text-gray-600" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-bold text-gray-900 truncate">AWS Hosting Services</p>
                      <p className="text-xs text-gray-500 truncate mt-0.5">Monthly Cloud Infrastructure</p>
                    </div>
                    <div className="text-right flex-shrink-0">
                      <p className="text-sm font-bold text-gray-900">- RM 845.50</p>
                      <p className="text-xs text-gray-400 mt-0.5">Yesterday, 04:12 PM</p>
                    </div>
                  </div>
                  {/* Item 3 */}
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center flex-shrink-0">
                      <ArrowLeftRight className="w-5 h-5 text-gray-600" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-bold text-gray-900 truncate">Internal Transfer</p>
                      <p className="text-xs text-gray-500 truncate mt-0.5">Operating to Reserves</p>
                    </div>
                    <div className="text-right flex-shrink-0">
                      <p className="text-sm font-bold text-gray-900">RM 5,000.00</p>
                      <p className="text-xs text-gray-400 mt-0.5">12/10, 09:00 AM</p>
                    </div>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
