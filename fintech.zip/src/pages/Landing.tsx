import { Link } from 'react-router-dom';

export default function Landing() {
  return (
    <div className="bg-background text-on-background min-h-screen flex flex-col font-body-md overflow-x-hidden">
      {/* TopAppBar */}
      <header className="bg-background dark:bg-background docked full-width top-0 w-full z-50">
        <div className="flex justify-between items-center w-full px-margin-mobile md:px-margin-desktop py-4 max-w-container-max-width mx-auto">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-primary dark:text-inverse-primary" style={{ fontVariationSettings: "'FILL' 1" }}>
              hourglass_empty
            </span>
            <span className="font-headline-sm text-headline-sm font-bold text-primary dark:text-inverse-primary">
              FinTech
            </span>
          </div>
          <div className="flex items-center gap-6">
            <Link to="/login" className="font-label-lg text-label-lg text-on-surface-variant hover:text-primary transition-colors hidden sm:block">
              Login
            </Link>
            <Link to="/register" className="bg-primary text-on-primary font-label-lg text-label-lg py-2.5 px-6 rounded-full hover:bg-primary-container hover:text-on-primary-container transition-colors shadow-sm">
              Get Started
            </Link>
          </div>
        </div>
      </header>

      {/* Main Content Canvas */}
      <main className="flex-grow flex items-center justify-center p-margin-mobile md:p-margin-desktop w-full relative z-10 overflow-hidden bg-surface-container-low">
        {/* Abstract Background Decoration */}
        <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none opacity-40">
          <div className="absolute top-[-10%] left-[-5%] w-[40%] h-[40%] rounded-full bg-primary-fixed blur-[100px]"></div>
          <div className="absolute bottom-[-10%] right-[-5%] w-[50%] h-[50%] rounded-full bg-secondary-fixed blur-[120px]"></div>
        </div>

        {/* Hero Section */}
        <div className="w-full max-w-container-max-width mx-auto z-10 flex flex-col items-center text-center py-12 md:py-24">
          <div className="w-16 h-16 bg-primary-container rounded-full flex items-center justify-center mb-6">
            <span className="material-symbols-outlined text-on-primary-container text-4xl" style={{ fontVariationSettings: "'FILL' 1" }}>
              hourglass_empty
            </span>
          </div>
          
          <h1 className="font-display-lg text-display-lg text-on-surface mb-6 font-bold leading-tight max-w-3xl">
            Financial clarity for your <span className="text-primary tracking-tight">food business.</span>
          </h1>
          <p className="font-body-lg text-body-lg text-on-surface-variant mb-10 max-w-2xl">
            Join FinTech to manage your stall efficiently. Track daily sales, manage cash vs e-wallet splits, and get AI-powered insights to grow your stall.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto justify-center">
            <Link to="/register" className="bg-primary text-on-primary font-label-lg text-label-lg py-4 px-8 rounded-full hover:bg-primary-container hover:text-on-primary-container transition-colors shadow-sm flex items-center justify-center gap-2">
              Create Free Account
              <span className="material-symbols-outlined text-[20px]">arrow_forward</span>
            </Link>
            <Link to="/dashboard" className="bg-surface text-on-surface border border-outline-variant font-label-lg text-label-lg py-4 px-8 rounded-full hover:bg-surface-container-highest transition-colors shadow-sm flex items-center justify-center gap-2">
              <span className="material-symbols-outlined text-[20px]">monitoring</span>
              View Live Demo
            </Link>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-surface-container-low dark:bg-inverse-surface border-t border-outline-variant dark:border-outline full-width bottom-0 z-10 relative">
        <div className="w-full py-8 px-margin-mobile md:px-margin-desktop mt-auto flex flex-col md:flex-row justify-between items-center gap-4 max-w-container-max-width mx-auto">
          <div className="font-title-md text-title-md font-bold text-on-surface dark:text-inverse-on-surface flex items-center gap-2">
            <span className="material-symbols-outlined text-on-surface dark:text-inverse-on-surface">hourglass_empty</span>
            FinTech
          </div>
          <div className="flex gap-6">
            <a href="#" className="font-body-md text-body-md text-on-surface-variant dark:text-on-surface-variant hover:text-primary dark:hover:text-inverse-primary transition-colors">Privacy Policy</a>
            <a href="#" className="font-body-md text-body-md text-on-surface-variant dark:text-on-surface-variant hover:text-primary dark:hover:text-inverse-primary transition-colors">Terms of Service</a>
            <a href="#" className="font-body-md text-body-md text-on-surface-variant dark:text-on-surface-variant hover:text-primary dark:hover:text-inverse-primary transition-colors">Contact Support</a>
          </div>
          <div className="font-label-sm text-label-sm text-on-surface-variant dark:text-on-surface-variant">
            © 2026 FinTech. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
}
