import { Hourglass, HelpCircle, User, Lock, EyeOff, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function SignIn() {
  return (
    <div className="min-h-screen flex flex-col font-sans bg-surface-container-low text-on-surface">
      {/* TopAppBar */}
      <header className="full-width top-0 w-full z-50">
        <div className="flex justify-between items-center w-full px-4 md:px-6 py-4 max-w-[1200px] mx-auto">
          <Link to="/" className="flex items-center gap-2">
            <Hourglass className="text-primary w-6 h-6" />
            <span className="text-2xl font-bold text-primary">FinTech</span>
          </Link>
        </div>
      </header>

      {/* Main Content Canvas */}
      <main className="flex-grow flex items-center justify-center p-4 md:p-6 w-full relative overflow-hidden bg-surface-container-low">
        
        {/* Abstract Background Decoration */}
        <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none opacity-40">
          <div className="absolute top-[-10%] left-[-5%] w-[40%] h-[40%] rounded-full bg-primary-fixed blur-[100px]"></div>
          <div className="absolute bottom-[-10%] right-[-5%] w-[50%] h-[50%] rounded-full bg-secondary-fixed blur-[120px]"></div>
        </div>

        {/* Sign In Card */}
        <div className="w-full max-w-md bg-surface rounded-[24px] shadow-sm border border-outline-variant/30 p-8 z-10 flex flex-col items-center">
          
          {/* Logo & Header */}
          <div className="w-12 h-12 bg-primary-container rounded-full flex items-center justify-center mb-6">
            <Hourglass className="text-on-primary-container w-6 h-6" />
          </div>
          <h1 className="text-2xl text-on-surface mb-2 font-normal">Sign In</h1>
          <p className="text-sm text-on-surface-variant mb-8 text-center">Welcome back to FinTech. Please enter your details.</p>

          {/* Segmented Control */}
          <div className="w-full bg-surface-container-highest rounded-full p-1 flex mb-8">
            <button className="flex-1 py-2 px-4 rounded-full bg-surface text-on-surface shadow-sm text-sm font-medium transition-all">Admin Login</button>
            <button className="flex-1 py-2 px-4 rounded-full text-on-surface-variant hover:text-on-surface text-sm font-medium transition-all">Staff Login</button>
          </div>

          {/* Form */}
          <form className="w-full space-y-5">
            {/* Email/Phone Field */}
            <div className="w-full">
              <label htmlFor="identifier" className="block text-sm font-medium text-on-surface mb-1">Email / Phone Number</label>
              <div className="relative">
                <User className="absolute left-4 top-1/2 -translate-y-1/2 text-on-surface-variant w-5 h-5" />
                <input 
                  type="text" 
                  id="identifier" 
                  name="identifier" 
                  placeholder="Enter email or phone" 
                  className="w-full bg-surface-container-low border border-outline-variant text-on-surface text-base rounded-[16px] pl-12 pr-4 py-3 focus:ring-2 focus:ring-primary focus:border-primary transition-all outline-none" 
                />
              </div>
            </div>

            {/* Password Field */}
            <div className="w-full">
              <div className="flex justify-between items-center mb-1">
                <label htmlFor="password" className="block text-sm font-medium text-on-surface">Password</label>
                <a href="#" className="text-[11px] font-medium text-primary hover:opacity-80 transition-opacity">Forgot Password?</a>
              </div>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-on-surface-variant w-5 h-5" />
                <input 
                  type="password" 
                  id="password" 
                  name="password" 
                  placeholder="Enter your password" 
                  className="w-full bg-surface-container-low border border-outline-variant text-on-surface text-base rounded-[16px] pl-12 pr-12 py-3 focus:ring-2 focus:ring-primary focus:border-primary transition-all outline-none" 
                />
                <EyeOff className="absolute right-4 top-1/2 -translate-y-1/2 text-on-surface-variant cursor-pointer hover:text-on-surface w-5 h-5" />
              </div>
            </div>

            {/* Remember Me */}
            <div className="flex items-center pt-2">
              <input 
                type="checkbox" 
                id="remember" 
                className="w-5 h-5 rounded-[4px] border-outline text-primary focus:ring-primary bg-surface-container-low" 
              />
              <label htmlFor="remember" className="ml-2 text-sm text-on-surface-variant">Remember me for 30 days</label>
            </div>

            {/* Submit Button */}
            <div className="pt-4 w-full">
              <Link to="/dashboard" className="w-full bg-primary text-on-primary text-sm font-medium py-4 rounded-full hover:bg-primary-container hover:text-on-primary-container transition-colors shadow-sm flex items-center justify-center gap-2">
                Login
                <ArrowRight className="w-5 h-5" />
              </Link>
            </div>
          </form>

          {/* Sign Up Link */}
          <div className="mt-8 text-center border-t border-outline-variant/30 pt-6 w-full">
             <p className="text-sm text-on-surface-variant">
                 Don't have an account? 
                 <Link to="/register" className="text-sm text-primary font-bold hover:underline ml-1">Sign Up</Link>
             </p>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-surface-container-low border-t border-outline-variant full-width bottom-0 z-10 relative">
        <div className="w-full py-8 px-4 md:px-6 mt-auto flex flex-col md:flex-row justify-between items-center gap-4 max-w-[1200px] mx-auto">
          <div className="text-base font-bold text-on-surface flex items-center gap-2">
            <Hourglass className="text-on-surface w-5 h-5" />
            FinTech
          </div>
          <div className="flex gap-6">
            <a href="#" className="text-sm text-on-surface-variant hover:text-primary transition-colors">Privacy Policy</a>
            <a href="#" className="text-sm text-on-surface-variant hover:text-primary transition-colors">Terms of Service</a>
            <a href="#" className="text-sm text-on-surface-variant hover:text-primary transition-colors">Contact Support</a>
          </div>
          <div className="text-[11px] text-on-surface-variant">
            © 2024 FinTech. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
}
